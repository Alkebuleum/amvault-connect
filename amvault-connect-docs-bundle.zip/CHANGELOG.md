# Changelog

## 0.1.2
- Docs: full integration guide, troubleshooting for BigInt & estimateGas.
- SDK: guidance for decimal string `value` in tx requests.

## 0.1.1
- Configurable `appName`; customizable sign-in message; verify returned message.
- AmVault: signs caller-provided `message` and echoes it back.

## 0.1.0
- Initial public release.

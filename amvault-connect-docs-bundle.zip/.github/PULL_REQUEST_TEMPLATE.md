## Summary
Describe the change and why.

## Changes
- …

## Testing
- [ ] Built locally
- [ ] Tried in example app

## Checklist
- [ ] README updated (if needed)
- [ ] No breaking changes without major bump
